# Lab 09 — Reliable Event Processing

**Carlos Centeio — a22207219**  
**Computação Distribuída · 2026/2027**

Esta versão foi reconstruída sobre a estrutura **Lab 04 + a API e migrações do Lab 05 do repositório `a22207219/Aula5`**, integrando as ideias dos Labs 07–08 e as melhorias de fiabilidade do Lab 09. Preserva os endpoints HTTP e o modelo `pt.ulusofona.cd` do Lab 05, em vez de inventar um segundo modelo de Order Service. Não substitui nem altera o repositório GitHub original.

## Novidades Lab 09

- `MessageEnvelope<T>` com `messageId`, `type`, `timestamp`, `correlationId`, `causationId` e `payload`.
- O Order Service publica `OrderConfirmed` ao Kafka; o Product Service consome e diminui stock de forma transacional. O pedido `POST /api/v1/orders/{id}/confirm` já **não decrementa stock por HTTP**.
- Migração adicional `product-service/V5__processed_events.sql`; `PRIMARY KEY(message_id,consumer_group)` impede o mesmo evento de atualizar stock duas vezes. Também guarda o efeito por encomenda para impedir alterações repetidas com outra mensagem.
- `@RetryableTopic` com retries e tópico `order-confirmed-events.DLT`.
- Cancelamento compatível com Lab 05: emite `OrderCancelled` para o mesmo tópico/chave e o consumer compensa no stock depois da confirmação. Mensagens de cancelamento temporariamente antecipadas são reenviadas.
- Recuperação agendada (modelo Lab 05) de confirmações/cancelamentos presos em `CONFIRMING`/`CANCELLING`; o identificador de mensagem é determinístico e estável quando se repete uma tentativa.
- Stock REST do Lab 05 (`/stock`, `/stock/increment`, `/stock/decrement`) preservado e com ledger `stock_operation` independente.
- `SupplierDeactivated` publicado como envelope; Product Service descontinua os produtos desse fornecedor.
- Testes Testcontainers de replay Kafka (stock uma só vez) e DLT; testes JUnit do conversor.

## Compatibilidade de APIs Lab 05

`POST /api/v1/orders` continua a aceitar **`{"productId":"<UUID>","quantity":2}`**, e não uma lista `items`.

Endpoints mantidos: `GET/POST /api/v1/orders`, `GET/PUT/DELETE /api/v1/orders/{id}`, `POST /api/v1/orders/{id}/confirm` e `/cancel`.

Product Service: `POST /api/v1/products`, `GET /api/v1/products/{id}/stock`, `POST /api/v1/products/{id}/stock/increment` e `/decrement`.

O stock começa a zero e tem de ser incrementado usando um `operationId` UUID antes de confirmar uma encomenda.

## Executar no PowerShell

Requer Java 25, Docker Desktop com Docker Compose e portas livres 8081, 8082, 8083, 8090, 29092, 5444. Na raiz do projeto:

```powershell
Copy-Item .env.example .env
# Edita as passwords no .env se necessário.
.\mvnw.cmd clean verify
docker compose config
docker compose up -d --build
docker compose ps
```

Não uses `docker compose down -v` sem querer apagar os dados. Ao usar o Lab 04/05 em paralelo, liberta as portas em conflito.

UI Kafka: http://localhost:8090.

### Teste manual

```powershell
# Cria fornecedor ativo através da API existente (campos exigidos: name, email, active)
$supplier = Invoke-RestMethod 'http://localhost:8082/api/v1/suppliers' -Method Post -ContentType 'application/json' -Body '{"name":"Fornecedor Teste","email":"teste@example.org","active":true}'
$body = @{sku='LAB09-T1'; name='Produto Teste'; description=''; price=12.5; supplierId=$supplier.id} | ConvertTo-Json
$product = Invoke-RestMethod 'http://localhost:8081/api/v1/products' -Method Post -ContentType 'application/json' -Body $body
$stock = @{quantity=10;operationId=([guid]::NewGuid()).ToString()} | ConvertTo-Json
Invoke-RestMethod "http://localhost:8081/api/v1/products/$($product.id)/stock/increment" -Method Post -ContentType 'application/json' -Body $stock
$order = Invoke-RestMethod 'http://localhost:8083/api/v1/orders' -Method Post -ContentType 'application/json' -Body (@{productId=$product.id;quantity=2}|ConvertTo-Json)
Invoke-RestMethod "http://localhost:8083/api/v1/orders/$($order.id)/confirm" -Method Post
# A atualização via Kafka é assíncrona: repetir consulta até stock=8
Invoke-RestMethod "http://localhost:8081/api/v1/products/$($product.id)/stock"
```

### Testes

```powershell
.\mvnw.cmd -pl product-service -am test
.\mvnw.cmd clean verify
```

`OrderEventIntegrationTest` exige Docker ativo para PostgreSQL e Kafka Testcontainers. Captura a saída real destes comandos como prova de execução; não atribuir sucesso a testes não executados.

## Nota sobre limites e riscos

- **Não é uma cópia byte-a-byte do projeto do GitHub Aula5**: foi usada a estrutura do Lab04 recuperada e os contratos, pacotes e migrações públicos do Aula5, com a nova implementação Lab09.
- **A confirmação HTTP passa a ser eventualmente consistente**: um 200/CONFIRMED confirma o publish no broker, não a existência imediata de stock reservado. Se não existir stock, a mensagem vai à DLT e exige intervenção/reconciliação; para production é necessário um evento de sucesso/falha do Product Service para atualizar o estado da encomenda.
- O consumidor de cancelamento faz compensação após o evento de confirmação; se a confirmação não tiver sido processada ou estiver na DLT, o cancelamento pode terminar na DLT. Não deve ser considerado uma saga distribuída plenamente resolvida.
- Os produtores não têm transactional outbox: se o Kafka indisponibilizar, o Order Service mantém a transição pendente e o agendador reenvia com a mesma mensagem ID. O Supplier Service ainda tem uma janela de falha entre o commit SQL e a publicação de `SupplierDeactivated`.
- **Ainda não foi possível compilar/testar com Docker + Java 25 neste ambiente.** Foram realizados apenas controlos locais de estrutura, sintaxe básica e coerência de configuração. Não marcar como pronto para entrega antes de `mvn clean verify` e dos smoke tests de execução real.

**Referências:** https://github.com/a22207219/Aula5 e https://computacao-distribuida.gitbook.io/distributed-systems/NeQQJCioSDAubRdz3haF/laboratories/lab-09-reliable-event-processing
