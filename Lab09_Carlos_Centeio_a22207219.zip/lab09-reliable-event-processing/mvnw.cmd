@echo off
setlocal
set "MAVEN_VERSION=3.9.11"
set "MAVEN_HOME=%USERPROFILE%\.m2\wrapper\dists\apache-maven-%MAVEN_VERSION%"
set "MAVEN_BIN=%MAVEN_HOME%\bin\mvn.cmd"
if exist "%MAVEN_BIN%" goto run
set "DIST=%USERPROFILE%\.m2\wrapper\dists\apache-maven-%MAVEN_VERSION%-bin.zip"
if not exist "%DIST%" (
  echo Downloading Apache Maven %MAVEN_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/%MAVEN_VERSION%/apache-maven-%MAVEN_VERSION%-bin.zip'; New-Item -ItemType Directory -Force -Path (Split-Path '%DIST%') | Out-Null; Invoke-WebRequest -Uri $u -OutFile '%DIST%'"
  if errorlevel 1 exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $root=Split-Path '%MAVEN_HOME%'; $tmp=Join-Path $env:TEMP ('maven-extract-'+[guid]::NewGuid().ToString()); New-Item -ItemType Directory -Force -Path $tmp | Out-Null; try { Expand-Archive -Force '%DIST%' $tmp; $inner=Join-Path $tmp 'apache-maven-%MAVEN_VERSION%'; if(!(Test-Path (Join-Path $inner 'bin\mvn.cmd'))){throw 'Invalid Maven archive'}; if(Test-Path '%MAVEN_HOME%'){Remove-Item -Recurse -Force '%MAVEN_HOME%'}; Move-Item $inner '%MAVEN_HOME%' } finally { Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue }"
if errorlevel 1 exit /b 1
:run
call "%MAVEN_BIN%" %*
exit /b %ERRORLEVEL%
