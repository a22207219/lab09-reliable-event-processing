package pt.ulusofona.cd.order.client;
import org.springframework.web.service.annotation.GetExchange;import java.util.UUID;
import java.math.BigDecimal;
public interface ProductClient {
 @GetExchange("/api/v1/products/{id}") ProductInfo get(@org.springframework.web.bind.annotation.PathVariable UUID id);
 record ProductInfo(UUID id,String sku,String name,String description,BigDecimal price,UUID supplierId){}
}
