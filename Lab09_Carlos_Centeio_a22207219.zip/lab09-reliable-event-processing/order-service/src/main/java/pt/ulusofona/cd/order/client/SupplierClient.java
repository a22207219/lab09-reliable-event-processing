package pt.ulusofona.cd.order.client;
import org.springframework.web.service.annotation.GetExchange;import java.util.UUID;
public interface SupplierClient {
 @GetExchange("/api/v1/suppliers/{id}") SupplierInfo get(@org.springframework.web.bind.annotation.PathVariable UUID id);
 record SupplierInfo(UUID id,String name,boolean active){}
}
