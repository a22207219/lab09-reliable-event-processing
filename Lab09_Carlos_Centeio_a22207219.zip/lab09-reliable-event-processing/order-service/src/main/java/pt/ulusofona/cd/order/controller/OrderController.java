package pt.ulusofona.cd.order.controller;
import jakarta.validation.Valid;import org.springframework.web.bind.annotation.*;import org.springframework.http.*;import pt.ulusofona.cd.order.model.dto.*;import pt.ulusofona.cd.order.service.OrderService;import java.util.*;
@RestController @RequestMapping("/api/v1/orders") public class OrderController {
 private final OrderService service;public OrderController(OrderService service){this.service=service;}
 @PostMapping public ResponseEntity<OrderResponse> create(@Valid @RequestBody OrderRequest r){return ResponseEntity.status(HttpStatus.CREATED).body(service.create(r));}
 @GetMapping public List<OrderResponse> all(){return service.all();}
 @GetMapping("/{id}") public OrderResponse one(@PathVariable UUID id){return service.one(id);}
 @PutMapping("/{id}") public OrderResponse update(@PathVariable UUID id,@Valid @RequestBody OrderRequest r){return service.update(id,r);}
 @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable UUID id){service.delete(id);return ResponseEntity.noContent().build();}
 @PostMapping("/{id}/confirm") public OrderResponse confirm(@PathVariable UUID id){return service.confirm(id);}
 @PostMapping("/{id}/cancel") public OrderResponse cancel(@PathVariable UUID id){return service.cancel(id);}
}
