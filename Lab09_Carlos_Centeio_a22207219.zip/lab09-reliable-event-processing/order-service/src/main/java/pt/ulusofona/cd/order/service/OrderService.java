package pt.ulusofona.cd.order.service;
import org.springframework.stereotype.Service;import org.springframework.transaction.annotation.Transactional;import org.springframework.web.client.*;import org.springframework.http.HttpStatus;import org.springframework.web.server.ResponseStatusException;
import org.springframework.kafka.core.KafkaTemplate;import pt.ulusofona.cd.order.client.*;import pt.ulusofona.cd.order.model.Order;import pt.ulusofona.cd.order.model.dto.*;import pt.ulusofona.cd.order.repository.OrderRepository;import pt.ulusofona.cd.order.event.*;
import java.nio.charset.StandardCharsets;import java.util.*;import java.time.Instant;import java.util.concurrent.TimeUnit;import tools.jackson.databind.ObjectMapper;
@Service public class OrderService {
 private final OrderRepository repo;private final ProductClient products;private final SupplierClient suppliers;private final OrderTransitions transitions;
 private final KafkaTemplate<String,String> kafka;private final ObjectMapper mapper;
 public OrderService(OrderRepository repo,ProductClient products,SupplierClient suppliers,OrderTransitions transitions,KafkaTemplate<String,String> kafka,ObjectMapper mapper){this.repo=repo;this.products=products;this.suppliers=suppliers;this.transitions=transitions;this.kafka=kafka;this.mapper=mapper;}
 private ResponseStatusException bad(String m){return new ResponseStatusException(HttpStatus.CONFLICT,m);}
 private void validate(UUID productId){try{var p=products.get(productId);if(p==null||p.supplierId()==null)throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Invalid Product response");var s=suppliers.get(p.supplierId());if(s==null)throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Invalid Supplier response");if(!s.active())throw bad("Supplier inactive");}
 catch(HttpClientErrorException.NotFound ex){throw new ResponseStatusException(HttpStatus.UNPROCESSABLE_ENTITY,"Product or supplier not found",ex);}catch(ResourceAccessException|HttpServerErrorException ex){throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Remote service unavailable",ex);}}
 @Transactional public OrderResponse create(OrderRequest request){validate(request.productId());return OrderResponse.from(repo.save(new Order(request.productId(),request.quantity())));}
 @Transactional(readOnly=true) public List<OrderResponse> all(){return repo.findAll().stream().map(OrderResponse::from).toList();}
 @Transactional(readOnly=true) public OrderResponse one(UUID id){return OrderResponse.from(repo.findById(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Order not found")));}
 private Order locked(UUID id){return repo.locked(id).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Order not found"));}
 @Transactional public OrderResponse update(UUID id,OrderRequest request){Order o=locked(id);if(o.getStatus()!=Order.Status.PENDING)throw bad("Only pending orders can be edited");validate(request.productId());o.change(request.productId(),request.quantity());return OrderResponse.from(o);}
 @Transactional public void delete(UUID id){Order o=locked(id);if(o.getStatus()!=Order.Status.PENDING&&o.getStatus()!=Order.Status.CANCELLED)throw bad("Cancel the order before deletion");repo.delete(o);}
 private UUID idFor(UUID orderId,String action){return UUID.nameUUIDFromBytes((orderId+":"+action).getBytes(StandardCharsets.UTF_8));}
 private void publish(OrderResponse o,String action,String type){
  UUID messageId=idFor(o.id(),action);var envelope=new MessageEnvelope<>(messageId,type,Instant.now(),o.id(),null,new OrderEventPayload(o.id(),o.productId(),o.quantity()));
  try{kafka.send("order-confirmed-events",o.id().toString(),mapper.writeValueAsString(envelope)).get(15,TimeUnit.SECONDS);}
  catch(InterruptedException ex){Thread.currentThread().interrupt();throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Order in intermediate state; Kafka publish interrupted. Recovery will retry.",ex);}
  catch(Exception ex){throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,"Order in intermediate state; Kafka publish failed. Recovery will retry.",ex);}
 }
 // New in Lab 09: no synchronous stock deduction. The product consumer owns the stock effect.
 public OrderResponse confirm(UUID id){var o=transitions.beginConfirm(id);if(o.status()==Order.Status.CONFIRMED)return o;
  publish(o,"confirm","OrderConfirmed");return transitions.finish(id,Order.Status.CONFIRMING,Order.Status.CONFIRMED);
 }
 // Lab 05 cancellation contract is kept; compensation is now an event keyed by the same order ID.
 public OrderResponse cancel(UUID id){var o=transitions.beginCancel(id);if(o.status()==Order.Status.CANCELLED)return o;
  if(transitions.restoreRequired(id))publish(o,"cancel","OrderCancelled");
  return transitions.finish(id,Order.Status.CANCELLING,Order.Status.CANCELLED);
 }
}
