package pt.ulusofona.cd.product.event;
public class InsufficientStockException extends RuntimeException {public InsufficientStockException(String m){super(m);}}
