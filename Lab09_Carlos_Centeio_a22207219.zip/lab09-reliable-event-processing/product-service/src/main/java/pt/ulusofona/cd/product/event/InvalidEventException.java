package pt.ulusofona.cd.product.event;
public class InvalidEventException extends RuntimeException {public InvalidEventException(String m){super(m);}public InvalidEventException(String m,Throwable e){super(m,e);}}
