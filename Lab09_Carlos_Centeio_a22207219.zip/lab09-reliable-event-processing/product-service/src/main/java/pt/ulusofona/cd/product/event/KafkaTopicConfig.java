package pt.ulusofona.cd.product.event;
import org.apache.kafka.clients.admin.NewTopic;import org.springframework.context.annotation.Bean;import org.springframework.context.annotation.Configuration;
@Configuration public class KafkaTopicConfig {
 @Bean NewTopic orderEventsTopic(){return new NewTopic("order-confirmed-events",1,(short)1);}
 @Bean NewTopic supplierDeactivatedTopic(){return new NewTopic("supplier-deactivated-events",1,(short)1);}
}
