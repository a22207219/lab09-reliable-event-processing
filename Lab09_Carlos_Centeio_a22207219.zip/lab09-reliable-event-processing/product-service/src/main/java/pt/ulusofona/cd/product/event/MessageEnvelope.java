package pt.ulusofona.cd.product.event;
import java.time.Instant;import java.util.UUID;
public record MessageEnvelope<T>(UUID messageId,String type,Instant timestamp,UUID correlationId,UUID causationId,T payload) {}
