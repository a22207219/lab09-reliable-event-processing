package pt.ulusofona.cd.product.event;
import java.time.Instant;import java.util.*;import org.springframework.stereotype.Component;import tools.jackson.databind.ObjectMapper;
@Component public class MessageEnvelopeConverter {
 private final ObjectMapper mapper;public MessageEnvelopeConverter(ObjectMapper mapper){this.mapper=mapper;}
 public MessageEnvelope<OrderEventPayload> convert(String json){
  try{
   Map<?,?> body=mapper.readValue(json,Map.class);
   if(body==null)throw new InvalidEventException("Envelope cannot be null");
   UUID messageId=uuid(body,"messageId");UUID correlationId=uuid(body,"correlationId");
   Object causation=body.get("causationId");UUID causationId=causation==null?null:uuid(body,"causationId");
   Object type=body.get("type");if(!"OrderConfirmed".equals(type)&&!"OrderCancelled".equals(type))throw new InvalidEventException("Unsupported event type");
   Object timestamp=body.get("timestamp");if(!(timestamp instanceof String))throw new InvalidEventException("Missing timestamp");
   Instant when=Instant.parse((String)timestamp);
   if(!(body.get("payload") instanceof Map<?,?>))throw new InvalidEventException("Missing payload");
   OrderEventPayload payload=mapper.convertValue(body.get("payload"),OrderEventPayload.class);
   if(payload==null||payload.orderId()==null||payload.productId()==null||payload.quantity()<=0||!payload.orderId().equals(correlationId))throw new InvalidEventException("Invalid order payload");
   return new MessageEnvelope<>(messageId,(String)type,when,correlationId,causationId,payload);
  }catch(InvalidEventException e){throw e;}catch(RuntimeException e){throw new InvalidEventException("Malformed order event",e);}
 }
 private UUID uuid(Map<?,?> m,String key){Object v=m.get(key);if(!(v instanceof String s))throw new InvalidEventException("Missing "+key);UUID id=UUID.fromString(s);if(id.equals(new UUID(0,0)))throw new InvalidEventException("Empty "+key);return id;}
}
