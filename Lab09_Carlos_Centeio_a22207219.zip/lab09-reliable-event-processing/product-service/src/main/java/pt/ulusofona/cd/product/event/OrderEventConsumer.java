package pt.ulusofona.cd.product.event;
import org.apache.kafka.clients.consumer.ConsumerRecord;import org.slf4j.*;import org.springframework.kafka.annotation.*;import org.springframework.kafka.retrytopic.TopicSuffixingStrategy;import org.springframework.stereotype.Component;
@Component public class OrderEventConsumer {
 private static final Logger log=LoggerFactory.getLogger(OrderEventConsumer.class);
 private final MessageEnvelopeConverter converter;private final OrderEventProcessor processor;
 public OrderEventConsumer(MessageEnvelopeConverter converter,OrderEventProcessor processor){this.converter=converter;this.processor=processor;}
 @RetryableTopic(attempts="3",kafkaTemplate="kafkaTemplate",backOff=@BackOff(delay=1000,multiplier=2.0),retryTopicSuffix="-retry",dltTopicSuffix=".DLT",topicSuffixingStrategy=TopicSuffixingStrategy.SUFFIX_WITH_INDEX_VALUE,autoCreateTopics="true",numPartitions="1",replicationFactor="1",exclude={InvalidEventException.class,InsufficientStockException.class})
 @KafkaListener(topics="order-confirmed-events",groupId=OrderEventProcessor.CONSUMER_GROUP)
 public void consume(ConsumerRecord<String,String> record){var e=converter.convert(record.value());if(!e.payload().orderId().toString().equals(record.key()))throw new InvalidEventException("Kafka key differs from order ID");processor.process(e);}
 @DltHandler public void deadLetter(ConsumerRecord<String,String> record){log.error("Order event on DLT: topic={} partition={} offset={} key={}",record.topic(),record.partition(),record.offset(),record.key());}
}
