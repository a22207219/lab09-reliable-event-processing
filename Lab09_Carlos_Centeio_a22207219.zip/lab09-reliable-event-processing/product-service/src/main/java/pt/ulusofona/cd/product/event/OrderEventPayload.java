package pt.ulusofona.cd.product.event;
import java.util.UUID;
public record OrderEventPayload(UUID orderId,UUID productId,int quantity) {}
