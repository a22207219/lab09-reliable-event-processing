package pt.ulusofona.cd.product.event;
import java.util.UUID;import org.springframework.stereotype.Service;import org.springframework.transaction.annotation.Transactional;import org.springframework.jdbc.core.JdbcTemplate;
@Service public class OrderEventProcessor {
 public static final String CONSUMER_GROUP="product-service-group";
 private final JdbcTemplate jdbc;public OrderEventProcessor(JdbcTemplate jdbc){this.jdbc=jdbc;}
 @Transactional public void process(MessageEnvelope<OrderEventPayload> e){
  int registered=jdbc.update("INSERT INTO processed_events(message_id,consumer_group) VALUES (?,?) ON CONFLICT(message_id,consumer_group) DO NOTHING",e.messageId(),CONSUMER_GROUP);
  if(registered==0)return;
  OrderEventPayload p=e.payload();
  if("OrderConfirmed".equals(e.type()))confirm(p);else cancel(p);
 }
 private void confirm(OrderEventPayload p){
  Object[] existing=jdbc.query("SELECT product_id,quantity,cancelled FROM order_stock_effects WHERE order_id=? FOR UPDATE",rs->rs.next()?new Object[]{rs.getObject(1,UUID.class),rs.getInt(2),rs.getBoolean(3)}:null,p.orderId());
  if(existing!=null){if(!p.productId().equals(existing[0])||p.quantity()!=(Integer)existing[1])throw new InvalidEventException("Order event changed immutable product/quantity");return;}
  int affected=jdbc.update("UPDATE product SET stock=stock-?,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=? AND stock>=? AND is_discontinued=false",p.quantity(),p.productId(),p.quantity());
  if(affected==0){Integer count=jdbc.queryForObject("SELECT count(*) FROM product WHERE id=?",Integer.class,p.productId());
   if(count==null||count==0)throw new OrderNotReadyException("Product not found: "+p.productId());
   throw new InsufficientStockException("Insufficient stock or product discontinued: "+p.productId());}
  jdbc.update("INSERT INTO order_stock_effects(order_id,product_id,quantity,cancelled) VALUES (?,?,?,false)",p.orderId(),p.productId(),p.quantity());
 }
 private void cancel(OrderEventPayload p){
  Object[] effect=jdbc.query("SELECT product_id,quantity,cancelled FROM order_stock_effects WHERE order_id=? FOR UPDATE",rs->rs.next()?new Object[]{rs.getObject(1,UUID.class),rs.getInt(2),rs.getBoolean(3)}:null,p.orderId());
  if(effect==null)throw new OrderNotReadyException("Order not yet applied: "+p.orderId());
  if(!p.productId().equals(effect[0])||p.quantity()!=(Integer)effect[1])throw new InvalidEventException("Cancellation differs from original order");
  if((Boolean)effect[2])return;
  int changed=jdbc.update("UPDATE product SET stock=stock+?,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=?",p.quantity(),p.productId());
  if(changed!=1)throw new OrderNotReadyException("Product unavailable for refund");
  jdbc.update("UPDATE order_stock_effects SET cancelled=true WHERE order_id=?",p.orderId());
 }
}
