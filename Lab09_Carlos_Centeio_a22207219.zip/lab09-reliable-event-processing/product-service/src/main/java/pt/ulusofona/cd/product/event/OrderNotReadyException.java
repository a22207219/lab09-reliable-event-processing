package pt.ulusofona.cd.product.event;
public class OrderNotReadyException extends RuntimeException {public OrderNotReadyException(String m){super(m);}}
