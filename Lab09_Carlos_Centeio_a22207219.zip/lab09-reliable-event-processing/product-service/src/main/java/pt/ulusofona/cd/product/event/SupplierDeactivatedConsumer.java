package pt.ulusofona.cd.product.event;
import java.util.*;import org.springframework.kafka.annotation.KafkaListener;import org.springframework.jdbc.core.JdbcTemplate;import org.springframework.stereotype.Component;import org.springframework.transaction.annotation.Transactional;import tools.jackson.databind.ObjectMapper;
@Component public class SupplierDeactivatedConsumer {
 private final JdbcTemplate jdbc;private final ObjectMapper mapper;
 public SupplierDeactivatedConsumer(JdbcTemplate jdbc,ObjectMapper mapper){this.jdbc=jdbc;this.mapper=mapper;}
 @KafkaListener(topics="supplier-deactivated-events",groupId="product-supplier-deactivation-group")
 @Transactional public void consume(String json){
  try{Map<?,?> event=mapper.readValue(json,Map.class);
   if(event==null)throw new InvalidEventException("Missing supplier event");
   Map<?,?> payload;
   if(event.containsKey("payload")){if(!"SupplierDeactivated".equals(event.get("type")))throw new InvalidEventException("Wrong supplier event type");if(!(event.get("payload") instanceof Map<?,?> data))throw new InvalidEventException("Missing supplier payload");payload=data;}
   else payload=event; // backward compatibility with Lab 07/08 flat events
   Object raw=payload.get("supplierId");if(!(raw instanceof String value))throw new InvalidEventException("No supplierId");
   jdbc.update("UPDATE product SET is_discontinued=true,version=version+1,updated_at=CURRENT_TIMESTAMP WHERE supplier_id=? AND is_discontinued=false",UUID.fromString(value));
  }catch(InvalidEventException ex){throw ex;}catch(RuntimeException ex){throw new InvalidEventException("Invalid supplier event",ex);}
 }
}
