package pt.ulusofona.cd.product.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import pt.ulusofona.cd.product.model.Product;
import java.util.UUID;
public interface ProductRepository extends JpaRepository<Product,UUID>{long countBySupplierId(UUID supplierId);boolean existsBySkuIgnoreCase(String sku); @Modifying @Query(value="UPDATE product SET stock=stock-:quantity, version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=:id AND stock>=:quantity AND is_discontinued=false",nativeQuery=true) int decrement(@Param("id") UUID id,@Param("quantity") int quantity);
 @Modifying @Query(value="UPDATE product SET stock=stock+:quantity, version=version+1,updated_at=CURRENT_TIMESTAMP WHERE id=:id",nativeQuery=true) int increment(@Param("id") UUID id,@Param("quantity") int quantity);
 @Query(value="SELECT stock FROM product WHERE id=:id",nativeQuery=true) Integer stock(@Param("id") UUID id);
}
