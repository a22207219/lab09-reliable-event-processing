ALTER TABLE product ADD COLUMN is_discontinued BOOLEAN NOT NULL DEFAULT FALSE;
CREATE INDEX ix_product_supplier_discontinued ON product(supplier_id,is_discontinued);
