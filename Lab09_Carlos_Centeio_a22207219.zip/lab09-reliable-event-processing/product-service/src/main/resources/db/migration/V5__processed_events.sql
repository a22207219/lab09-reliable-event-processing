CREATE TABLE processed_events (
 message_id UUID NOT NULL,
 consumer_group VARCHAR(120) NOT NULL,
 processed_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(message_id,consumer_group)
);
CREATE TABLE order_stock_effects (
 order_id UUID PRIMARY KEY,
 product_id UUID NOT NULL,
 quantity INTEGER NOT NULL CHECK(quantity>0),
 cancelled BOOLEAN NOT NULL DEFAULT FALSE
);
