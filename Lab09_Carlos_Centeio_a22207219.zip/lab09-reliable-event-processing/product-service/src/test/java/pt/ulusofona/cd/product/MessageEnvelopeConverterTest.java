package pt.ulusofona.cd.product;
import org.junit.jupiter.api.Test;import pt.ulusofona.cd.product.event.*;import tools.jackson.databind.ObjectMapper;import java.time.Instant;import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;
class MessageEnvelopeConverterTest {
 private final MessageEnvelopeConverter converter=new MessageEnvelopeConverter(tools.jackson.databind.json.JsonMapper.builder().build());
 @Test void invalidEventIsRejected(){assertThrows(InvalidEventException.class,()->converter.convert("{\"type\":\"SomethingElse\"}"));}
 @Test void validEventIsParsed(){UUID order=UUID.randomUUID();UUID product=UUID.randomUUID();UUID msg=UUID.randomUUID();
  String json="""
   {"messageId":"%s","type":"OrderConfirmed","timestamp":"%s","correlationId":"%s","causationId":null,"payload":{"orderId":"%s","productId":"%s","quantity":2}}
  """.formatted(msg,Instant.now(),order,order,product);
  var e=converter.convert(json);assertEquals(msg,e.messageId());assertEquals(2,e.payload().quantity());}
}
