package pt.ulusofona.cd.product;
import pt.ulusofona.cd.product.event.*;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.kafka.KafkaContainer;
import org.testcontainers.postgresql.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;
import tools.jackson.databind.ObjectMapper;

import static org.junit.jupiter.api.Assertions.*;

/** Real PostgreSQL + Kafka: no mocks, no screenshots as substitutes for assertions. */
@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
class OrderEventIntegrationTest {
    @Container
    static final KafkaContainer KAFKA = new KafkaContainer(
        DockerImageName.parse("apache/kafka:4.3.1"));
    @Container
    static final PostgreSQLContainer POSTGRES = new PostgreSQLContainer(
        DockerImageName.parse("postgres:18"))
        .withDatabaseName("productdb").withUsername("store").withPassword("storepass");

    @DynamicPropertySource
    static void properties(DynamicPropertyRegistry registry) {
        registry.add("spring.kafka.bootstrap-servers", KAFKA::getBootstrapServers);
        registry.add("spring.datasource.url", POSTGRES::getJdbcUrl);
        registry.add("spring.datasource.username", POSTGRES::getUsername);
        registry.add("spring.datasource.password", POSTGRES::getPassword);
    }

    @Autowired JdbcTemplate jdbc;
    @Autowired KafkaTemplate<String, String> kafka;
    @Autowired ObjectMapper mapper;

    @Test
    void replayedEventDecrementsStockOnlyOnce() throws Exception {
        UUID productId = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO product(id,sku,name,description,price,supplier_id,created_at,updated_at,version,is_discontinued,stock)
            VALUES (?, ?, 'Replay Test Product', '', 5.00, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0, false, 10)
            """, productId, "SKU-"+productId, UUID.randomUUID());
        UUID messageId = UUID.randomUUID();
        UUID orderId = UUID.randomUUID();
        String event = envelope(messageId, orderId, productId, 2);
        // Same byte-for-byte record twice. Both Kafka sends must be acknowledged.
        kafka.send(new ProducerRecord<>("order-confirmed-events", orderId.toString(), event))
            .get(15, TimeUnit.SECONDS);
        kafka.send(new ProducerRecord<>("order-confirmed-events", orderId.toString(), event))
            .get(15, TimeUnit.SECONDS);

        // Do not assert before both records have been processed and offsets committed.
        // Use the actual end offset: another test may have already written a record.
        long requiredOffset = topicEndOffset();
        await(Duration.ofSeconds(40), () -> committedOffset() >= requiredOffset,
            "Product consumer did not commit both replayed records");
        Integer stock = jdbc.queryForObject("SELECT stock FROM product WHERE id=?", Integer.class, productId);
        Integer count = jdbc.queryForObject("""
            SELECT count(*) FROM processed_events
            WHERE message_id=? AND consumer_group=?
            """, Integer.class, messageId, OrderEventProcessor.CONSUMER_GROUP);
        assertEquals(8, stock, "Duplicated Kafka delivery must not subtract stock twice");
        assertEquals(1, count, "Ledger must contain exactly one marker");
    }

    @Test
    void retriableFailureReachesDeadLetterTopic() throws Exception {
        UUID missingProductId = UUID.randomUUID();
        UUID orderId = UUID.randomUUID();
        UUID messageId = UUID.randomUUID();
        try (KafkaConsumer<String, String> probe = newDltConsumer()) {
            probe.subscribe(List.of("order-confirmed-events.DLT"));
            String event = envelope(messageId, orderId, missingProductId, 2);
            kafka.send("order-confirmed-events", orderId.toString(), event)
                .get(15, TimeUnit.SECONDS);
            boolean received = false;
            long deadline = System.nanoTime() + Duration.ofSeconds(45).toNanos();
            while (System.nanoTime() < deadline && !received) {
                var records = probe.poll(Duration.ofMillis(500));
                for (var record : records) {
                    if (event.equals(record.value()) &&
                            "order-confirmed-events.DLT".equals(record.topic())) {
                        received = true;
                        break;
                    }
                }
            }
            assertTrue(received, "Retry exhaustion must forward the record to the DLT");
        }
        Integer rows = jdbc.queryForObject("SELECT count(*) FROM processed_events WHERE message_id=?",
            Integer.class, messageId);
        assertEquals(0, rows, "An unsuccessful transaction must not leave a ledger marker");
    }

    private KafkaConsumer<String, String> newDltConsumer() {
        Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA.getBootstrapServers());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "dlt-probe-" + UUID.randomUUID());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        return new KafkaConsumer<>(props);
    }

    private String envelope(UUID messageId, UUID orderId, UUID productId, int quantity) {
        var payload = new OrderEventPayload(orderId, productId, quantity);
        return mapper.writeValueAsString(new MessageEnvelope<>(
            messageId, "OrderConfirmed", Instant.now(), orderId, null, payload));
    }

    private long topicEndOffset() throws Exception {
        try (AdminClient admin = AdminClient.create(Map.of(
                AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA.getBootstrapServers()))) {
            var partition = new TopicPartition("order-confirmed-events", 0);
            return admin.listOffsets(Map.of(partition, org.apache.kafka.clients.admin.OffsetSpec.latest()))
                .all().get(10, TimeUnit.SECONDS).get(partition).offset();
        }
    }

    private long committedOffset() {
        try (AdminClient admin = AdminClient.create(Map.of(
                AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, KAFKA.getBootstrapServers()))) {
            var offsets = admin.listConsumerGroupOffsets(OrderEventProcessor.CONSUMER_GROUP)
                .partitionsToOffsetAndMetadata().get(3, TimeUnit.SECONDS);
            var marker = offsets.get(new TopicPartition("order-confirmed-events", 0));
            return marker == null ? -1 : marker.offset();
        } catch (Exception ignored) {
            return -1;
        }
    }

    private static void await(Duration timeout, BooleanSupplier condition, String failure)
            throws InterruptedException {
        long deadline = System.nanoTime() + timeout.toNanos();
        while (System.nanoTime() < deadline) {
            if (condition.getAsBoolean()) return;
            Thread.sleep(250);
        }
        fail(failure);
    }
}
