$ErrorActionPreference = 'Stop'
$base = 'http://localhost'
$id = [guid]::NewGuid().ToString('N').Substring(0,10)
$supplier = Invoke-RestMethod "${base}:8082/api/v1/suppliers" -Method Post -ContentType 'application/json' -Body (@{name='Fornecedor Lab09';email="lab09-$id@example.org";active=$true} | ConvertTo-Json)
$product = Invoke-RestMethod "${base}:8081/api/v1/products" -Method Post -ContentType 'application/json' -Body (@{sku="LAB09-$id";name='Produto de Teste';description='';price=9.95;supplierId=$supplier.id} | ConvertTo-Json)
$op = @{quantity=10;operationId=([guid]::NewGuid().ToString())} | ConvertTo-Json
Invoke-RestMethod "${base}:8081/api/v1/products/$($product.id)/stock/increment" -Method Post -ContentType 'application/json' -Body $op | Out-Null
$order = Invoke-RestMethod "${base}:8083/api/v1/orders" -Method Post -ContentType 'application/json' -Body (@{productId=$product.id;quantity=2} | ConvertTo-Json)
Invoke-RestMethod "${base}:8083/api/v1/orders/$($order.id)/confirm" -Method Post | Out-Null
$ok = $false
for ($i=0; $i -lt 40; $i++) {
  $stock = Invoke-RestMethod "${base}:8081/api/v1/products/$($product.id)/stock"
  if ($stock.stock -eq 8) { $ok=$true; break }
  Start-Sleep -Seconds 1
}
if (-not $ok) { throw "Stock não chegou a 8 após confirmar encomenda: $($order.id)." }
# replay endpoint yields same ID; should not debit stock again
Invoke-RestMethod "${base}:8083/api/v1/orders/$($order.id)/confirm" -Method Post | Out-Null
Start-Sleep -Seconds 2
$stock = Invoke-RestMethod "${base}:8081/api/v1/products/$($product.id)/stock"
if ($stock.stock -ne 8) { throw "Confirmar duas vezes alterou o stock: $($stock.stock)." }
Write-Host "LAB09: confirmação e stock aprovados. Encomenda $($order.id); stock 8."
Invoke-RestMethod "${base}:8083/api/v1/orders/$($order.id)/cancel" -Method Post | Out-Null
$ok = $false
for ($i=0; $i -lt 40; $i++) {
  $stock = Invoke-RestMethod "${base}:8081/api/v1/products/$($product.id)/stock"
  if ($stock.stock -eq 10) {$ok=$true;break}
  Start-Sleep -Seconds 1
}
if (-not $ok) { throw "Cancelamento não restaurou o stock; último valor $($stock.stock)." }
Write-Host "LAB09: cancelamento de encomenda e devolução de stock aprovados."
