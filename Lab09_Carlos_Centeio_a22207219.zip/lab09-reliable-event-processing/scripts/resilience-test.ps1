$ErrorActionPreference = "Stop"
$uri = "http://localhost:8081/api/v1/products"
$body = @{ sku="LAB4-FAILURE-$(Get-Random)"; name="Failure test"; description="Expected failure"; price=1.00; supplierId=[guid]::NewGuid() } | ConvertTo-Json

Write-Host "Stopping supplier-service to exercise retry/fallback/circuit breaker..."
$failed = $false
docker compose stop supplier-service | Out-Host
try {
  for ($i=1; $i -le 4; $i++) {
    $sw=[Diagnostics.Stopwatch]::StartNew()
    try {
      Invoke-WebRequest -Method Post -Uri $uri -ContentType "application/json" -Body $body -UseBasicParsing | Out-Null
      Write-Host "Call $i unexpectedly succeeded"
      $failed = $true
    } catch {
      $status=$_.Exception.Response.StatusCode.value__
      $sw.Stop()
      Write-Host "Call $i -> HTTP $status in $($sw.Elapsed.TotalSeconds.ToString('0.00'))s"
      if ($status -ne 503) { $failed = $true }
      if ($sw.Elapsed.TotalSeconds -gt 10) { $failed = $true }
    }
  }
} finally {
  docker compose start supplier-service | Out-Host
  Write-Host "Waiting for supplier-service to become healthy again..."
  $recovered = $false
  for ($attempt = 1; $attempt -le 30; $attempt++) {
    try {
      $health = Invoke-RestMethod -Method Get -Uri "http://localhost:8082/actuator/health" -TimeoutSec 2
      if ($health.status -eq "UP") { $recovered = $true; break }
    } catch { }
    Start-Sleep -Seconds 2
  }
  if (-not $recovered) { throw "supplier-service did not recover to UP within 60 seconds." }
}
if ($failed) { throw "Resilience test failed: expected HTTP 503 within 10 seconds for every call." }
Write-Host "Resilience exercise passed: HTTP 503 within bounded response times."
Write-Host "Checking circuit-breaker metrics endpoint..."
$metrics = Invoke-RestMethod -Method Get -Uri "http://localhost:8081/actuator/metrics/resilience4j.circuitbreaker.calls" -TimeoutSec 5
if ($metrics.name -ne "resilience4j.circuitbreaker.calls") { throw "Unexpected circuit-breaker metric response." }
$tags = $metrics.availableTags | Where-Object { $_.tag -eq "name" }
if ($tags -and -not ($tags.values -contains "supplierService")) { throw "Metrics do not include the supplierService circuit breaker." }
Write-Host "Circuit-breaker metrics endpoint OK: $($metrics.name)"
