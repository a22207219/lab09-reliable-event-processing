package pt.ulusofona.cd.supplier.event;
import org.apache.kafka.clients.admin.NewTopic;import org.springframework.context.annotation.*;
@Configuration public class KafkaTopicConfig {@Bean NewTopic supplierDeactivatedTopic(){return new NewTopic("supplier-deactivated-events",1,(short)1);}}
