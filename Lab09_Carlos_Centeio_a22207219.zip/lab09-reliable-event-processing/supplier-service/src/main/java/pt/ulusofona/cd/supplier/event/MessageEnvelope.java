package pt.ulusofona.cd.supplier.event;
import java.time.Instant;import java.util.UUID;
public record MessageEnvelope<T>(UUID messageId,String type,Instant timestamp,UUID correlationId,UUID causationId,T payload) {}
