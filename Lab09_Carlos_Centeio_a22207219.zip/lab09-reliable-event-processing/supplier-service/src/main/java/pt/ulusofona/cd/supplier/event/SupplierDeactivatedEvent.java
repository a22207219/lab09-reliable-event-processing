package pt.ulusofona.cd.supplier.event;
import java.time.Instant;import java.util.UUID;
public record SupplierDeactivatedEvent(UUID supplierId,UUID eventId,Instant occurredAt,String supplierName,String reason) {}
